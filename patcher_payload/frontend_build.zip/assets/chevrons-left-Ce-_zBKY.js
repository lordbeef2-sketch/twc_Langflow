import{bC as e}from"./index-h4RuT1jr.js";const t=[["path",{d:"m11 17-5-5 5-5",key:"13zhaf"}],["path",{d:"m18 17-5-5 5-5",key:"h8a8et"}]],a=e("chevrons-left",t);export{t as __iconNode,a as default};
