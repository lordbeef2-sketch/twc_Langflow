import{bC as o}from"./index-h4RuT1jr.js";const t=[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]],r=o("arrow-down-left",t);export{t as __iconNode,r as default};
