import{bC as o}from"./index-h4RuT1jr.js";const t=[["path",{d:"m7 7 10 10",key:"1fmybs"}],["path",{d:"M17 7v10H7",key:"6fjiku"}]],e=o("arrow-down-right",t);export{t as __iconNode,e as default};
