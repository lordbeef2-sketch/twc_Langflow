import{bB as c}from"./index-CQDKE7wU.js";const e=[["circle",{cx:"9",cy:"9",r:"7",key:"p2h5vp"}],["circle",{cx:"15",cy:"15",r:"7",key:"19ennj"}]],o=c("blend",e);export{e as __iconNode,o as default};
