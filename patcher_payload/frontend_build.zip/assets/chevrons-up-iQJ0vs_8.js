import{bB as e}from"./index-CQDKE7wU.js";const o=[["path",{d:"m17 11-5-5-5 5",key:"e8nh98"}],["path",{d:"m17 18-5-5-5 5",key:"2avn1x"}]],t=e("chevrons-up",o);export{o as __iconNode,t as default};
