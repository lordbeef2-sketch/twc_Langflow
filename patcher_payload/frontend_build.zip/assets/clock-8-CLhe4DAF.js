import{bC as c}from"./index-h4RuT1jr.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l-4 2",key:"imc3wl"}]],l=c("clock-8",o);export{o as __iconNode,l as default};
