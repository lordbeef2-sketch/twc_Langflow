import{bC as o}from"./index-h4RuT1jr.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],e=o("arrow-up",r);export{r as __iconNode,e as default};
