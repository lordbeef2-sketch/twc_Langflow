import{bC as c}from"./index-h4RuT1jr.js";const e=[["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}]],r=c("circle-small",e);export{e as __iconNode,r as default};
