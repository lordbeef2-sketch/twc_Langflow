import{bC as c}from"./index-h4RuT1jr.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],t=c("clock-4",o);export{o as __iconNode,t as default};
