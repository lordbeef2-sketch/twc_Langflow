import{bB as o}from"./index-CQDKE7wU.js";const e=[["path",{d:"m7 6 5 5 5-5",key:"1lc07p"}],["path",{d:"m7 13 5 5 5-5",key:"1d48rs"}]],n=o("chevrons-down",e);export{e as __iconNode,n as default};
