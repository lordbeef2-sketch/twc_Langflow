import{bC as c}from"./index-h4RuT1jr.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6h4",key:"135r8i"}]],r=c("clock-3",o);export{o as __iconNode,r as default};
