import{bC as o}from"./index-h4RuT1jr.js";const e=[["path",{d:"m7 18 6-6-6-6",key:"lwmzdw"}],["path",{d:"M17 6v12",key:"1o0aio"}]],a=o("chevron-last",e);export{e as __iconNode,a as default};
