import{bC as o}from"./index-h4RuT1jr.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],t=o("arrow-down",e);export{e as __iconNode,t as default};
