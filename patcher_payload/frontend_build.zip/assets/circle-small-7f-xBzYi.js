import{bB as c}from"./index-CQDKE7wU.js";const e=[["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}]],r=c("circle-small",e);export{e as __iconNode,r as default};
